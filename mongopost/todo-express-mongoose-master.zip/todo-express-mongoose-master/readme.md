安装依赖

```
npm isntall
```

启动项目

```
node index.js
```

- WEB 框架使用 `express`
- 数据库操作框架使用 `mongoose`
- 模板引擎使用 `ejs`
- 前端布局框架使用 `BootStrap 3`

数据库配置文件 `./lib/mongoose.js`
